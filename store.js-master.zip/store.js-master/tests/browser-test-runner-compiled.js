var store = require('../store+json2.min')
var browserTestRunner = require('./browser-test-runner')

browserTestRunner.run(store)